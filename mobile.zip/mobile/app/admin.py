from django.contrib import admin
from .models import category,product,appinfo,client
# Register your models here.

admin.site.register(category)
admin.site.register(product)
admin.site.register(appinfo)
admin.site.register(client)